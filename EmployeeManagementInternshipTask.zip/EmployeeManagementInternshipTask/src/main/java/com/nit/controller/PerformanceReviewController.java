package com.nit.controller;

import com.nit.entity.PerformanceReview;
import com.nit.service.PerformanceReviewService;
import com.nit.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reviews")
public class PerformanceReviewController {

    @Autowired
    private PerformanceReviewService service;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public String listReviews(Model model) {
        model.addAttribute("reviews", service.getAllReviews());
        return "reviews"; // reviews-list.html
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("review", new PerformanceReview());
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "review-form"; // review-form.html
    }

    @PostMapping
    public String saveReview(@ModelAttribute("review") PerformanceReview review) {
        service.saveReview(review);
        return "redirect:/reviews";
    }

    @GetMapping("/edit/{id}")
    public String editReview(@PathVariable Long id, Model model) {
        model.addAttribute("review", service.getReviewById(id).orElse(new PerformanceReview()));
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "review-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteReview(@PathVariable Long id) {
        service.deleteReview(id);
        return "redirect:/reviews";
    }
}
