package com.nit.controller;

import com.nit.entity.Attendance;
import com.nit.service.AttendanceService;
import com.nit.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {

    @Autowired
    private AttendanceService service;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public String listAttendance(Model model) {
        model.addAttribute("attendanceList", service.getAllAttendance());
        return "attendance"; // attendance-list.html
    }

    @GetMapping("/new")
    public String showForm(Model model) {
        model.addAttribute("attendance", new Attendance());
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "attendance-form"; // attendance-form.html
    }

    @PostMapping
    public String saveAttendance(@ModelAttribute("attendance") Attendance attendance) {
        service.saveAttendance(attendance);
        return "redirect:/attendance";
    }

    @GetMapping("/edit/{id}")
    public String editAttendance(@PathVariable Long id, Model model) {
        model.addAttribute("attendance", service.getAttendanceById(id).orElse(new Attendance()));
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "attendance-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteAttendance(@PathVariable Long id) {
        service.deleteAttendance(id);
        return "redirect:/attendance";
    }
}
