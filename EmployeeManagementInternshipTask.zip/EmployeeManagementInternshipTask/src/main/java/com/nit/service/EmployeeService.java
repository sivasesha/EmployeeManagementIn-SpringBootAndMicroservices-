package com.nit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nit.entity.Employee;
import com.nit.repo.AttendanceRepository;
import com.nit.repo.EmployeeRepository;
import com.nit.repo.PerformanceReviewRepository;

import jakarta.transaction.Transactional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    @Autowired
    private AttendanceRepository attendanceRepo;

    @Autowired
    private PerformanceReviewRepository reviewRepo;

    public Employee saveEmployee(Employee emp) {
        return repo.save(emp);
    }

    public List<Employee> getAllEmployees() {
        return repo.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return repo.findById(id);
    }

    public List<Employee> getEmployeesByDepartment(Long deptId) {
        return repo.findByDepartmentId(deptId);
    }

    public Employee updateEmployee(Long id, Employee emp) {
        return repo.findById(id).map(existing -> {
            existing.setName(emp.getName());
            existing.setEmail(emp.getEmail());
            existing.setPhone(emp.getPhone());
            existing.setDepartment(emp.getDepartment());
            return repo.save(existing);
        }).orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    @Transactional
    public void deleteEmployee(Long id) {
        attendanceRepo.deleteByEmployeeId(id);
        reviewRepo.deleteByEmployeeId(id);
        repo.deleteById(id);
    }
}
